﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using WildFarm.Models.Food;

namespace WildFarm.Models
{
    public class Cat : Feline
    {
        private const double CatWM = 0.3;
        public Cat(string name, double weight, string livingRegion, string breed) : base(name, weight, livingRegion, breed)
        {
        }

        public override ICollection<Type> Collection => new HashSet<Type>() { typeof(Meat), typeof(Vegetable) };
        public override string SoundProducer()
        {
            return "Meow";
            
        }

        protected override double WeightMultiplier => CatWM;
    }
}
