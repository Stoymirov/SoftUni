﻿using System.Linq.Expressions;

namespace Animals
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            while (true)
            {
                string animalType = Console.ReadLine();

                if (animalType == "Beast!")
                {
                    break;
                }

                string[] tokens = Console.ReadLine().Split();
                try
                {
                    switch (animalType)
                    {
                        case "Dog":
                        {
                            Dog dog = new Dog(tokens[0], int.Parse(tokens[1]), tokens[2]);
                            Console.WriteLine(dog);
                            break;
                        }
                        case "Frog":
                        {
                            Frog frog = new Frog(tokens[0], int.Parse(tokens[1]), tokens[2]);
                            Console.WriteLine(frog);
                            break;
                        }
                        case "Cat":
                        {
                            Cat cat = new Cat(tokens[0], int.Parse(tokens[1]), tokens[2]);
                            Console.WriteLine(cat);
                            break;
                        }
                        case "Tomcat":
                        {
                            Tomcat tomcat = new Tomcat(tokens[0], int.Parse(tokens[1]));
                            Console.WriteLine(tomcat);
                            break;
                        }
                        case "Kitten":
                        {
                            Kitten kitten = new Kitten(tokens[0], int.Parse(tokens[1]));
                            Console.WriteLine(kitten);
                            break;
                        }
                    }

                }


                catch(Exception e)
                {
                    Console.WriteLine("Invalid input!");
                } 
                
            }
        }   
    }
}