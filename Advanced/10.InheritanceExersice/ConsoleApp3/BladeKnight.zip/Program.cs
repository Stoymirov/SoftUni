﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            Hero hero = new Hero("strfan", 2);
            Console.WriteLine(hero);
        }
    }
}